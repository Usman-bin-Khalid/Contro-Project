package com.example.product

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
