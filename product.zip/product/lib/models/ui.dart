import 'package:flutter/cupertino.dart';

class Ui{
  final String title;
  final String description;
  final IconData iconData;
  final IconData iconDatatwo;

  Ui({required this.title, required this.description, required this.iconData, required this.iconDatatwo});
}