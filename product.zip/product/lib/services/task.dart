import 'dart:nativewrappers/_internal/vm/lib/core_patch.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:product/models/task.dart';

class TaskServeices {
  //Create Task
  //Get all task

  Stream<List<TaskModel>> getAllTasks() {
    return FirebaseFirestore.instance
        .collection('taskCollection')
        .snapshots()
        .map((event) =>
            event.docs.map((e) => TaskModel.fromJson(e.data())).toList());
  }

   Stream 

}
