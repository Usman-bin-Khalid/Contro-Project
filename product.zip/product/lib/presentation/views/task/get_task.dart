import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:product/models/ui.dart';

class GetTask extends StatefulWidget{
  @override
  State<GetTask> createState() => _GetTaskState();
}

class _GetTaskState extends State<GetTask> {
  List<Ui> getUserFeedBack = [
  Ui(title: "Title", description: "Description", iconData: Icons.person, iconDatatwo: Icons.add),
  Ui(title: "Title", description: "Description", iconData: Icons.person, iconDatatwo: Icons.add),
  Ui(title: "Title", description: "Description", iconData: Icons.person, iconDatatwo: Icons.add),
  Ui(title: "Title", description: "Description", iconData: Icons.person, iconDatatwo: Icons.add),
  ];

  @override
  Widget build(BuildContext context) {
     return Scaffold(
       appBar: AppBar(
         title: Text('Get', style: TextStyle(fontWeight: FontWeight.w500 , fontSize:24 , color: Colors.black),),
         centerTitle: true,
       ),
       body: _getBody(context),
     );
  }

    Widget _getBody(BuildContext context){
      return Column(
        children: [
          Expanded(

            child: ListView.builder(
                itemCount: getUserFeedBack.length,
                itemBuilder: (

                context,i){
              return ListTile(
                title: Text(getUserFeedBack[i].title,  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),),
                subtitle: Text(getUserFeedBack[i].description, style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w300
                ),),
                leading: Icon(getUserFeedBack[i].iconData, size: 30,),
                trailing: Icon(getUserFeedBack[i].iconDatatwo,),
              );
            }),
          ),

        ],
      );
    }
}